from distutils.core import setup

setup(
	name			= 'cities',
	version			= '1.0.0',
	py_modules		=['cities'],
	author			= 'ruslan',
	author_email	= 'ruslan.merdeev@mail.ru',
	url				= '',
	description		= 'Create file with cities',
)