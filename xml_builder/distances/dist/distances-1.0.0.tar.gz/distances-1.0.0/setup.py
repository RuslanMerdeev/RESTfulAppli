from distutils.core import setup

setup(
	name			= 'distances',
	version			= '1.0.0',
	py_modules		=['distances'],
	author			= 'ruslan',
	author_email	= 'ruslan.merdeev@mail.ru',
	url				= '',
	description		= 'Create file with distances',
)